# Shipping Container README
Modular fantasy wall terrain set. With or without magnet cut outs

## Parts
The magnetic fence parts have cut outs for 2mm height x 3mm diameter magnets. 

## Install

To run the code you'll need to install python and cqindustry
https://github.com/medicationforall/cqindustry

Refer to the cqindustry repository for installation instructions.
With dependencies installed run the following from a command line in the code directory.

```
python container_greeble_closed.py
```

OR 

```
python container_greeble_open.py
```

OR

```
python container_greebled_closed.stl
```

OR

```
python container_greebled_open.stl
```

These will generate the stl's

## Customization
With the code you can customize the generated models to suit

### Container Documentation
https://github.com/medicationforall/cqindustry/blob/main/documentation/container.md

### Part Specs
https://miniforall.com/shippingcontainer