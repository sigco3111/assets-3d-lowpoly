# Thank You for Downloading!

Hi there!

Thank you so much for downloading my model! I hope you enjoy it and can put it to good use in your projects.

I'm still a beginner when it comes to 3D modeling and texturing, so I apologize if some parts of the model or textures are a little rough or imperfect. I'm always learning and trying to improve with each new model I make!

If you end up using this model in your game or another project, feel free to leave a comment or share a link to your work. I'd love to check it out and see what you've created!

Thank you again for your support

---

## License — CC0 1.0 Universal

This model and its included textures are released under **CC0 1.0 Universal (Public Domain Dedication)**.

You are free to:

- Use this model in personal or commercial projects.
- Modify, edit, or remix the model however you like.
- Use the model in games, animations, renders, and other creative works.
- Share or redistribute the model.

**No attribution is required!** However, credit is always appreciated.

You don't need to ask for permission to use this model.

For more information, visit the official license page:

https://creativecommons.org/publicdomain/zero/1.0/

---

